#!/bin/sh

cd plugins/
cp -f check_online_miners /usr/lib/nagios/plugins
cp -f check_cpu_usage /usr/lib/nagios/plugins
cp -f check_mem /usr/lib/nagios/plugins
cp -f check_ufw /usr/lib/nagios/plugins

cd ../conf.d
cp -f commands.conf /etc/icinga2/conf.d
cp -f hosts.conf /etc/icinga2/conf.d
cp -f services.conf /etc/icinga2/conf.d